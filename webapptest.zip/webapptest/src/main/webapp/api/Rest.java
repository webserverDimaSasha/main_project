package webapp.api;


import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import webapp.Entity.User;

import java.util.ArrayList;
import java.util.List;

@RestController(value = "/rest")
public class Rest {

    @RequestMapping(name = "/getString1",method = RequestMethod.GET)
    public String getString(){
        return "Hi, Dimmi! If u see this text than we fuck this system =)";
    }

    @RequestMapping(name = "/getString2",method = RequestMethod.GET)
    public String getOtherString(){
        return "It's other string. Can u see this? Ohhh, yeap, goodboy! =)";
    }

    @RequestMapping(name = "/getJSON",produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
    public List<User> getJSON(){
        List<User> userList=new ArrayList<User>();
        userList.add(new User("Bob",(long) 1,25));
        userList.add(new User("Jon",(long) 2,12));
        userList.add(new User("Cowboy",(long)3,1000));
        return userList;
    }

    @RequestMapping(name = "/getStrJSON",produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
    public String getStrJSON(){
        User user=new User("StrUser",(long)11,30);
        return user.toString();
    }
}
