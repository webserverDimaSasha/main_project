package webapp.Entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class User {

    private String name;
    private Long id;
    private Integer age;

    public User(String name, Long id, Integer age){
        this.age=age;
        this.id=id;
        this.name=name;
    }

    public String getName() {return name;}

    public void setName(String name) {this.name = name;}

    public Long getId() {return id;}

    public void setId(Long id) {this.id = id;}

    public Integer getAge() {return age;}

    public void setAge(Integer age) {this.age = age;}

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", age=" + age +
                '}';
    }
}
